from django.apps import AppConfig


class ConfectionaryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'confectionary'
    verbose_name = 'Данные кондитерских'
